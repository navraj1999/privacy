
#!/bin/bash

echo "Currently set postgres directory:" $PG_DIR

TOOL='bazel'
DP_DIR='differential_privacy/postgres'

$TOOL build $DP_DIR:anon_func.so
/bin/mkdir -p $PG_DIR/lib
/bin/mkdir -p $PG_DIR/share/extension
/usr/bin/install -c -m 755 $TOOL-bin/$DP_DIR/anon_func.so $PG_DIR/lib/
/usr/bin/install -c -m 644 $DP_DIR/anon_func.control $PG_DIR/share/extension/
/usr/bin/install -c -m 644 $DP_DIR/anon_func--1.0.0.sql  $PG_DIR/share/extension/
