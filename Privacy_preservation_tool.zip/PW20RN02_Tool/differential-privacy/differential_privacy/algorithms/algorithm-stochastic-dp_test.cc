
#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "differential_privacy/algorithms/approx-bounds.h"
#include "differential_privacy/algorithms/bounded-mean.h"
#include "differential_privacy/algorithms/bounded-standard-deviation.h"
#include "differential_privacy/algorithms/bounded-sum.h"
#include "differential_privacy/algorithms/bounded-variance.h"
#include "differential_privacy/algorithms/count.h"
#include "differential_privacy/algorithms/numerical-mechanisms-testing.h"
#include "differential_privacy/algorithms/order-statistics.h"
#include "differential_privacy/algorithms/util.h"
#include "differential_privacy/testing/sequence.h"
#include "differential_privacy/testing/stochastic_tester.h"

namespace differential_privacy {
namespace {

using ::differential_privacy::continuous::Max;
using ::differential_privacy::continuous::Median;
using ::differential_privacy::continuous::Min;
using ::differential_privacy::continuous::Percentile;
using ::differential_privacy::test_utils::SeededLaplaceMechanism;
using ::differential_privacy::testing::HaltonSequence;
using ::differential_privacy::testing::StochasticTester;
using ::differential_privacy::testing::StoredSequence;

constexpr int kNumDatasetsToTest = 500;
constexpr int kSmallNumDatasetsToTest = 100;
constexpr int kNumSamplesPerHistogram = 20000;

template <typename T>
class StochasticDifferentialPrivacyTest : public ::testing::Test {
 protected:
  void SetUp() override {}
  void TearDown() override {}
};

typedef ::testing::Types<BoundedSum<double>, BoundedMean<double>,
                         BoundedVariance<double>,
                         BoundedStandardDeviation<double>>
    BoundedDpAlgorithms;
TYPED_TEST_SUITE(StochasticDifferentialPrivacyTest, BoundedDpAlgorithms);

TYPED_TEST(StochasticDifferentialPrivacyTest, AllBoundedDpAlgorithms) {
  auto sequence = absl::make_unique<HaltonSequence<double>>(
      testing::DefaultDatasetSize(), true /* sorted_only */,
      testing::DefaultDataScale(), testing::DefaultDataOffset());
  auto algorithm = typename TypeParam::Builder()
                       .SetLaplaceMechanism(
                           absl::make_unique<SeededLaplaceMechanism::Builder>())
                       .SetEpsilon(DefaultEpsilon())
                       .SetLower(sequence->RangeMin())
                       .SetUpper(sequence->RangeMax())
                       .Build()
                       .ValueOrDie();
  StochasticTester<double> tester(std::move(algorithm), std::move(sequence),
                                  kSmallNumDatasetsToTest,
                                  kNumSamplesPerHistogram);
  EXPECT_TRUE(tester.Run());
}

TEST(StochasticDifferentialPrivacyTest, Max) {
  auto sequence = absl::make_unique<HaltonSequence<double>>(
      testing::DefaultDatasetSize(), true /* sorted_only */,
      testing::DefaultDataScale(), testing::DefaultDataOffset());

  double lower = sequence->RangeMin();
  double upper = sequence->RangeMax();
  auto algorithm = Max<double>::Builder()
                       .SetLaplaceMechanism(
                           absl::make_unique<SeededLaplaceMechanism::Builder>())
                       .SetEpsilon(DefaultEpsilon())
                       .SetLower(lower)
                       .SetUpper(upper)
                       .Build()
                       .ValueOrDie();
  StochasticTester<double> tester(std::move(algorithm), std::move(sequence),
                                  kSmallNumDatasetsToTest,
                                  kNumSamplesPerHistogram);
  EXPECT_TRUE(tester.Run());
}

TEST(StochasticDifferentialPrivacyTest, Min) {
  auto sequence = absl::make_unique<HaltonSequence<double>>(
      testing::DefaultDatasetSize(), true /* sorted_only */,
      testing::DefaultDataScale(), testing::DefaultDataOffset());

  double lower = sequence->RangeMin();
  double upper = sequence->RangeMax();
  auto algorithm = Min<double>::Builder()
                       .SetLaplaceMechanism(
                           absl::make_unique<SeededLaplaceMechanism::Builder>())
                       .SetEpsilon(DefaultEpsilon())
                       .SetLower(lower)
                       .SetUpper(upper)
                       .Build()
                       .ValueOrDie();
  StochasticTester<double> tester(std::move(algorithm), std::move(sequence),
                                  kSmallNumDatasetsToTest, kNumDatasetsToTest);
  EXPECT_TRUE(tester.Run());
}

TEST(StochasticDifferentialPrivacyTest, Median) {
  auto sequence = absl::make_unique<HaltonSequence<double>>(
      testing::DefaultDatasetSize(), true /* sorted_only */,
      testing::DefaultDataScale(), testing::DefaultDataOffset());

  double lower = sequence->RangeMin();
  double upper = sequence->RangeMax();
  auto algorithm = Median<double>::Builder()
                       .SetLaplaceMechanism(
                           absl::make_unique<SeededLaplaceMechanism::Builder>())
                       .SetEpsilon(DefaultEpsilon())
                       .SetLower(lower)
                       .SetUpper(upper)
                       .Build()
                       .ValueOrDie();
  StochasticTester<double> tester(std::move(algorithm), std::move(sequence),
                                  kSmallNumDatasetsToTest, kNumDatasetsToTest);
  EXPECT_TRUE(tester.Run());
}

TEST(StochasticDifferentialPrivacyTest, Percentile) {
  auto sequence = absl::make_unique<HaltonSequence<double>>(
      testing::DefaultDatasetSize(), true /* sorted_only */,
      testing::DefaultDataScale(), testing::DefaultDataOffset());

  double percentile = 0.9;
  double lower = sequence->RangeMin();
  double upper = sequence->RangeMax();
  auto algorithm = Percentile<double>::Builder()
                       .SetLaplaceMechanism(
                           absl::make_unique<SeededLaplaceMechanism::Builder>())
                       .SetPercentile(percentile)
                       .SetEpsilon(DefaultEpsilon())
                       .SetLower(lower)
                       .SetUpper(upper)
                       .Build()
                       .ValueOrDie();
  StochasticTester<double> tester(std::move(algorithm), std::move(sequence),
                                  kSmallNumDatasetsToTest,
                                  kNumSamplesPerHistogram);
  EXPECT_TRUE(tester.Run());
}

TEST(StochasticDifferentialPrivacyTest, Count) {
  auto sequence = absl::make_unique<HaltonSequence<int64_t>>(
      testing::DefaultDatasetSize(), true /* sorted_only */,
      testing::DefaultDataScale(), testing::DefaultDataOffset());
  std::unique_ptr<Count<int64_t>> algorithm =
      Count<int64_t>::Builder()
          .SetLaplaceMechanism(
              absl::make_unique<SeededLaplaceMechanism::Builder>())
          .SetEpsilon(DefaultEpsilon())
          .Build()
          .ValueOrDie();
  StochasticTester<int64_t> tester(std::move(algorithm), std::move(sequence),
                                 kNumDatasetsToTest, kNumSamplesPerHistogram);
  EXPECT_TRUE(tester.Run());
}

// For Count, by creating a single dataset of a particular size, executing the
// DP tester for this dataset on a single path in the search space is
// equivalent to testing all datasets of that size, assuming that the
// algorithm does not depend on the actual values of in the dataset.
TEST(StochasticDifferentialPrivacyTest, CountNonBranchingSearch) {
  constexpr int kCountNonBranchingSearchDatasetSize = 2500;
  std::vector<int64_t> dataset(kCountNonBranchingSearchDatasetSize, 0);
  std::vector<std::vector<int64_t>> datasets;
  datasets.emplace_back(dataset);
  auto sequence = absl::make_unique<StoredSequence<int64_t>>(datasets);
  std::unique_ptr<Count<int64_t>> algorithm =
      Count<int64_t>::Builder()
          .SetLaplaceMechanism(
              absl::make_unique<SeededLaplaceMechanism::Builder>())
          .SetEpsilon(DefaultEpsilon())
          .Build()
          .ValueOrDie();
  StochasticTester<int64_t> tester(std::move(algorithm), std::move(sequence),
                                 /*num_datasets=*/1, kNumSamplesPerHistogram,
                                 /*disable_search_branching=*/true);
  EXPECT_TRUE(tester.Run());
}

// The stochaster tester tests the first output element: approximate minimum.
TEST(StochasticDifferentialPrivacyTest, ApproxBoundsMinimum) {
  auto sequence = absl::make_unique<HaltonSequence<double>>(
      testing::DefaultDatasetSize(), true, testing::DefaultDataScale(),
      testing::DefaultDataOffset());
  auto algorithm = ApproxBounds<double>::Builder()
                       .SetLaplaceMechanism(
                           absl::make_unique<SeededLaplaceMechanism::Builder>())
                       .SetEpsilon(1)
                       .SetBase(2)
                       .SetNumBins(1)
                       .SetScale(.2)
                       .SetSuccessProbability(.9)
                       .Build()
                       .ValueOrDie();
  StochasticTester<double> tester(std::move(algorithm), std::move(sequence),
                                  kNumDatasetsToTest, kNumSamplesPerHistogram);
  EXPECT_TRUE(tester.Run());
}

TYPED_TEST(StochasticDifferentialPrivacyTest, AllApproxBoundedDpAlgorithms) {
  auto sequence = absl::make_unique<HaltonSequence<double>>(
      testing::DefaultDatasetSize(), true, testing::DefaultDataScale(),
      testing::DefaultDataOffset());

  std::unique_ptr<ApproxBounds<double>> bounds =
      ApproxBounds<double>::Builder()
          .SetLaplaceMechanism(
              absl::make_unique<SeededLaplaceMechanism::Builder>())
          .SetEpsilon(DefaultEpsilon())
          .SetScale(.2)
          .SetBase(2)
          .SetNumBins(1)
          .SetSuccessProbability(.90)
          .Build()
          .ValueOrDie();

  // The sum mechanism is remade for every run of the algorithm. Thus, we need
  // to ensure an outside generator is passed into the mechanism builder.
  std::seed_seq seed({1, 1, 1, 1, 1});
  std::mt19937 rand_gen(seed);
  auto mech_builder = SeededLaplaceMechanism::Builder().rand_gen(&rand_gen);
  auto algorithm =
      typename TypeParam::Builder()
          .SetLaplaceMechanism(
              absl::make_unique<SeededLaplaceMechanism::Builder>(mech_builder))
          .SetEpsilon(DefaultEpsilon())
          .SetApproxBounds(std::move(bounds))
          .Build()
          .ValueOrDie();
  StochasticTester<double> tester(std::move(algorithm), std::move(sequence),
                                  kNumDatasetsToTest, kNumSamplesPerHistogram);
  EXPECT_TRUE(tester.Run());
}

}  // namespace
}  // namespace differential_privacy
