Project ID: PW20RN02

Project Type : MINOR RESEARCH PROJECT

Project Title: PRIVACY PRESERVING ANALYTICS

Team Members: SRINIKETH M SHENOY(01FB16ECS486) , VIKRAM G(01FB16ECS484)

Project Guide: Dr. RAHUL NAGPAL

Project Abstract: It is a project aimed at optimizing the performance overhead that is taken by the existing privacy preserving queries
		  This project will allow a user to use the service provider apps without the worry of personal privacy breach and at 
		  at the same time allows the comanies to run their analytics on the user data for the company to grow.	

Code Execution : To execute this code you need to build this code first 

Steps to install  
Note: Your internet must be really stable for this to work correctly else you might come across errors like boring ssl.

1 Go to the (main) differential-privacy dir

2 run(note u must have bazel version 3 installed) ‘bazel build differential_privacy/…’

Note : If this fails to build then do step 4 once and then do step 3 and then 4

3  “sudo apt-get install libreadline-dev bison flex”

 4   install the postgres 11 using “wget --no-check-certificates https://ftp.postgresql.org/pub/source/v11.0/postgresql-11.0.tar.gz”

5 cd postgress-11.0

6 tar -xvzf postgres-11.0.tar.gz   (pls install postgres 11.0 only)

7   “./configure
make
su
make install
adduser postgres
mkdir /usr/local/pgsql/data
chown postgres /usr/local/pgsql/data
su - postgres
/usr/local/pgsql/bin/initdb -D /usr/local/pgsql/data
/usr/local/pgsql/bin/postgres -D /usr/local/pgsql/data >logfile 2>&1 &
/usr/local/pgsql/bin/createdb test
/usr/local/pgsql/bin/psql test
”


8  put this in terminal to check the path of the spql files or use  the path where postgres sql is installed and use the same path in the number 10 

  sudo su postgres -c "psql -c 'show data_directory'"   

9 use that path from the postgress
    export PG_DIR=<path u found above>

10 in the differential privacy main folder execute this

“      differential_privacy/postgres/install_extension.sh            ” 

11 start your postgres server with

/usr/local/pgsql/bin/postgres -D /usr/local/pgsql/data >logfile 2>&1 &



12  in postgres use this

CREATE EXTENSION anon_func;

If it asks some file missing in some path just paste that file in that path or paste these both in that path   anon_func.control  and  anon_func--1.0.0.sql,

Note : only postgres 11 will work that is a dependency of the tool.

*******************************************
usage :

in the main folder ie in differential-privacy dir

type-->   python Privacy.py <databasename> "<query without the ';' at the end>"

example python Privcy.py uber "select sum(salary) from driver where driver.id=car_owner.id"


note: please provide the data in such a way that the tool atleast has to process 200 (example "select avg(salary)from bank where id<2000") records to get the output as 

googles pre-existing tool needs a minimum ammount of records to process

**Note: Also the password of the "postgres" user in the psql must be set as "password" or change it in the tool accordingly(NOT RECOMENDED).

